package com.example.myschool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
